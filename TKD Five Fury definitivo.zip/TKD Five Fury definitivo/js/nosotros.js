function mostrarMision() {
    let mision = document.getElementById("mision");

    if (mision.style.display === "none") {
        mision.style.display = "block";
    } else {
        mision.style.display = "none";
    }
}

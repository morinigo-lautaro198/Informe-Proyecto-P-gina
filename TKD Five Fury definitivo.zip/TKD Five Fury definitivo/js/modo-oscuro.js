// =========================
// CAMBIAR MODO OSCURO / CLARO
// Se usa en todas las páginas del sitio
// =========================

function cambiarModo() {

    document.body.classList.toggle("modo-oscuro");

    let boton = document.getElementById("botonModo");

    if (!boton) return;

    if (document.body.classList.contains("modo-oscuro")) {
        boton.innerHTML = "☀️ Modo claro";
    } else {
        boton.innerHTML = "🌙 Modo oscuro";
    }
}

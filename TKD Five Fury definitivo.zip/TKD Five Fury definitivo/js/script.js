function mostrarVocabulario() {

    let vocabulario = [
        { termino: "Dobok", significado: "Uniforme de Taekwondo" },
        { termino: "Dojang", significado: "Lugar de entrenamiento" },
        { termino: "Charyeot", significado: "Atención / Firme" },
        { termino: "Kyongnye", significado: "Saludo" },
        { termino: "Sabomnim", significado: "Maestro / Instructor" },
        { termino: "Makgi", significado: "Bloqueo / Defensa" }
    ];

    let numero = Math.floor(Math.random() * vocabulario.length);
    let palabra = vocabulario[numero];

    document.getElementById("resultado").innerHTML =
        "🇰🇷 <b>" + palabra.termino + ":</b> " + palabra.significado;
}


function elegirCinturon() {

    let cinturones = [
        { color: "Blanco", nivel: "Principiante" },
        { color: "Amarillo", nivel: "Iniciado" },
        { color: "Verde", nivel: "Intermedio" },
        { color: "Azul", nivel: "Intermedio" },
        { color: "Rojo", nivel: "Avanzado" },
        { color: "Negro", nivel: "Avanzado" }
    ];

    let numero = Math.floor(Math.random() * cinturones.length);
    let seleccion = cinturones[numero];

    document.getElementById("resultado").innerHTML =
        "🥋 Cinturón " + seleccion.color + " (" + seleccion.nivel + ")";
}
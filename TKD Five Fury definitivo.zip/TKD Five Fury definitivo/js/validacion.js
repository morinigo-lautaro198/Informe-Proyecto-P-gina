// =========================
// VALIDACIÓN DEL FORMULARIO DE INSCRIPCIÓN
// =========================

document.addEventListener("DOMContentLoaded", function () {

    let formulario = document.getElementById("Formulario");

    formulario.addEventListener("submit", function (event) {

        // Evita que el formulario se envíe antes de validar
        event.preventDefault();


        // =========================
        // OBTENER LOS VALORES
        // =========================

        let nombre = document.getElementById("nombre").value.trim();

        let apellido = document.getElementById("apellido").value.trim();

        let edad = parseInt(document.getElementById("edad").value);

        let fechaNacimiento =
            document.getElementById("fecha-nacimiento").value;

        let dni = document.getElementById("dni").value.trim();

        let domicilio = document.getElementById("domicilio").value.trim();

        let celular = document.getElementById("celular").value.trim();

        let correo = document.getElementById("correo").value.trim();

        let practicaTaekwondo = document.querySelector(
            'input[name="preg"]:checked'
        );

        let practicaOtraMarcial = document.querySelector(
            'input[name="pregunta"]:checked'
        );


        // =========================
        // EXPRESIONES REGULARES
        // =========================

        let soloLetras =
            /^[A-Za-zÁÉÍÓÚáéíóúÑñÜü\s]+$/;

        let soloNumeros =
            /^[0-9]+$/;

        let formatoCorreo =
            /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

        let formatoCelular =
            /^[0-9+\-\s]+$/;


        // =========================
        // VALIDAR NOMBRE
        // =========================

        if (nombre === "") {
            alert("Debe ingresar su nombre.");
            document.getElementById("nombre").focus();
            return;
        }

        if (!soloLetras.test(nombre)) {
            alert("El nombre solo puede contener letras y espacios.");
            document.getElementById("nombre").focus();
            return;
        }


        // =========================
        // VALIDAR APELLIDO
        // =========================

        if (apellido === "") {
            alert("Debe ingresar su apellido.");
            document.getElementById("apellido").focus();
            return;
        }

        if (!soloLetras.test(apellido)) {
            alert("El apellido solo puede contener letras y espacios.");
            document.getElementById("apellido").focus();
            return;
        }


        // =========================
        // VALIDAR EDAD
        // =========================

        if (isNaN(edad)) {
            alert("Debe ingresar su edad.");
            document.getElementById("edad").focus();
            return;
        }

        if (edad < 4 || edad > 50) {
            alert("La edad debe estar entre 4 y 50 años.");
            document.getElementById("edad").focus();
            return;
        }


        // =========================
        // VALIDAR FECHA
        // =========================

        if (fechaNacimiento === "") {
            alert("Debe ingresar su fecha de nacimiento.");
            document.getElementById("fecha-nacimiento").focus();
            return;
        }

        let fechaNac = new Date(fechaNacimiento);
        let fechaActual = new Date();

        if (fechaNac > fechaActual) {
            alert("La fecha de nacimiento no puede ser futura.");
            document.getElementById("fecha-nacimiento").focus();
            return;
        }


        // =========================
        // CALCULAR EDAD
        // =========================

        let edadCalculada =
            fechaActual.getFullYear() -
            fechaNac.getFullYear();

        let mes =
            fechaActual.getMonth() -
            fechaNac.getMonth();

        if (
            mes < 0 ||
            (mes === 0 &&
             fechaActual.getDate() < fechaNac.getDate())
        ) {
            edadCalculada--;
        }

        if (edad !== edadCalculada) {
            alert(
                "La edad ingresada no coincide con la fecha de nacimiento. " +
                "Edad calculada: " +
                edadCalculada +
                " años."
            );
            document.getElementById("fecha-nacimiento").focus();
            return;
        }


        // =========================
        // VALIDAR DNI
        // =========================

        if (dni === "") {
            alert("Debe ingresar su DNI.");
            document.getElementById("dni").focus();
            return;
        }

        if (!soloNumeros.test(dni)) {
            alert("El DNI solo puede contener números.");
            document.getElementById("dni").focus();
            return;
        }

        if (dni.length < 7 || dni.length > 8) {
            alert("El DNI debe tener entre 7 y 8 números.");
            document.getElementById("dni").focus();
            return;
        }


        // =========================
        // VALIDAR DOMICILIO
        // =========================

        if (domicilio === "") {
            alert("Debe ingresar su domicilio.");
            document.getElementById("domicilio").focus();
            return;
        }


        // =========================
        // VALIDAR CELULAR
        // =========================

        if (celular === "") {
            alert("Debe ingresar su número de celular.");
            document.getElementById("celular").focus();
            return;
        }

        if (!formatoCelular.test(celular)) {
            alert("El número de celular contiene caracteres no válidos.");
            document.getElementById("celular").focus();
            return;
        }


        // =========================
        // VALIDAR CORREO
        // =========================

        if (correo === "") {
            alert("Debe ingresar su correo electrónico.");
            document.getElementById("correo").focus();
            return;
        }

        if (!formatoCorreo.test(correo)) {
            alert("Ingrese un correo electrónico válido.");
            document.getElementById("correo").focus();
            return;
        }


        // =========================
        // VALIDAR RADIO TAEKWONDO
        // =========================

        if (!practicaTaekwondo) {
            alert("Debe indicar si practicó alguna vez taekwondo.");
            document.getElementById("taekwondo-si").focus();
            return;
        }


        // =========================
        // VALIDAR RADIO OTRA ARTE MARCIAL
        // =========================

        if (!practicaOtraMarcial) {
            alert("Debe indicar si practicó otra arte marcial.");
            document.getElementById("marcial-si").focus();
            return;
        }


        // =========================
        // TODO CORRECTO
        // =========================

        alert("¡Inscripción realizada correctamente!");

        HTMLFormElement.prototype.submit.call(formulario);

    });

});

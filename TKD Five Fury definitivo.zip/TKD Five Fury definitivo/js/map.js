 window.addEventListener('load', function () {
            var map = L.map('map').setView([51.505, -0.09], 13);

            L.tileLayer('https://tile.openstreetmap.org/{z}/{x}/{y}.png', {
                maxZoom: 19,
                referrerPolicy: 'no-referrer-when-downgrade',
                attribution: '&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors'
            }).addTo(map);

            L.marker([51.5, -0.09]).addTo(map)
                .bindPopup('TKD Five Fury | Escuela de Taekwondo')
                .openPopup();

            setTimeout(function () { map.invalidateSize(); }, 200);
        });